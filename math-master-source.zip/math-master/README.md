# Math Master – Toán Tiểu học 3D

Game 3D giúp bé làm toán (lớp 2–4). React 19 + Three.js + Vite + Tailwind 4.

## Chạy trên máy
```
bun install   # hoặc npm install
bun run dev   # http://localhost:3000
```

## Tính năng đã thêm
- Giao diện game, màn hình chính với nhân vật chính làm các động tác (vẫy tay, nhảy, múa, xoay, lắc lư, reo hò, cúi chào)
- Vòng chơi: 3 tim, combo (5 combo hồi 1 tim), quái vật có thanh máu, hiệu ứng rung/chữ cổ vũ
- Bản đồ 8 màn mỗi lớp, chấm sao 1–3, mở khoá màn tiếp theo
- Cửa hàng trang phục (đổi màu áo/áo choàng nhân vật), pháo giấy ở màn kết quả

## Bản artifact
Thư mục `artifact-build/` chứa bản một-file (`math-master.html`) dùng CDN và các shim thay thế
(`three/addons`, `lucide-react`) để chạy trong artifact. Chỉ cần khi muốn build lại bản đó.
