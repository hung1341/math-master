import { X } from 'lucide-react';
import { useEffect, type ReactNode } from 'react';

interface GameModalShellProps {
  title: string;
  subtitle?: string;
  onClose: () => void;
  maxWidthClass?: string;
  children: ReactNode;
}

export function GameModalShell({
  title,
  subtitle,
  onClose,
  maxWidthClass = 'max-w-3xl',
  children,
}: GameModalShellProps) {
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [onClose]);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="game-modal-title"
      className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/70 backdrop-blur-[2px] p-4"
      onClick={onClose}
    >
      <div
        className={`flex max-h-[88vh] w-full ${maxWidthClass} flex-col overflow-hidden pop-in rounded-3xl border-4 border-white bg-white shadow-[0_8px_0_rgba(0,0,0,.35),0_20px_40px_rgba(0,0,0,.5)] dark:bg-slate-900`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4 border-b-4 border-amber-500 bg-gradient-to-b from-amber-300 to-orange-400 px-5 py-4 sm:px-6">
          <div>
            <h2
              id="game-modal-title"
              className="font-display text-2xl font-bold text-white [text-shadow:0_2px_0_rgba(0,0,0,.35)]"
            >
              {title}
            </h2>
            {subtitle && (
              <p className="mt-0.5 text-xs font-semibold text-orange-950/80">
                {subtitle}
              </p>
            )}
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Đóng cửa sổ"
            className="inline-flex h-10 w-10 items-center justify-center rounded-full border-[3px] border-white bg-red-500 text-white shadow-[0_3px_0_#991b1b] transition-transform hover:scale-110 active:translate-y-0.5 shrink-0"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>

        <div className="overflow-y-auto px-5 py-5 sm:px-6">{children}</div>
      </div>
    </div>
  );
}
