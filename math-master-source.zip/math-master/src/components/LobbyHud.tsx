import { BarChart3, ChevronDown, ChevronUp, Gift, Play, ScrollText, Settings, ShoppingBag } from 'lucide-react';
import { useState, type ReactNode } from 'react';
import { DIFFICULTIES, GRADES, QUIZ_MODES } from '../constants/gameConfig';
import type { ActiveModal, Difficulty, Grade, PlayerProfile, QuizModeId } from '../types/game';
import { formatNumber, getTodayIso } from '../utils/storage';

interface LobbyHudProps {
  profile: PlayerProfile;
  selectedGrade: Grade;
  selectedDifficulty: Difficulty;
  selectedMode: QuizModeId;
  onChangeGrade: (grade: Grade) => void;
  onChangeDifficulty: (difficulty: Difficulty) => void;
  onChangeMode: (mode: QuizModeId) => void;
  onOpenModal: (modal: ActiveModal) => void;
  onRequestStart: () => void;
}

function RoundBtn({ label, color, onClick, badge, children }: { label: string; color: string; onClick: () => void; badge?: boolean; children: ReactNode }) {
  return (
    <button type="button" onClick={onClick} aria-label={label} className="btn-game pointer-events-auto flex flex-col items-center gap-1 !rounded-2xl !px-3 !py-2" style={{ ['--c' as string]: color }}>
      <span className="relative">
        {children}
        {badge && <span className="absolute -top-2 -right-2 h-3.5 w-3.5 animate-ping rounded-full bg-red-500" />}
        {badge && <span className="absolute -top-2 -right-2 h-3.5 w-3.5 rounded-full border-2 border-white bg-red-500" />}
      </span>
      <span className="text-[11px] font-bold leading-none">{label}</span>
    </button>
  );
}

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button type="button" onClick={onClick} className={`chip ${active ? 'chip-on' : ''}`}>
      {children}
    </button>
  );
}

export function LobbyHud({ profile, selectedGrade, selectedDifficulty, selectedMode, onChangeGrade, onChangeDifficulty, onChangeMode, onOpenModal, onRequestStart }: LobbyHudProps) {
  const [showOptions, setShowOptions] = useState(false);
  const unclaimedDaily = profile.claimedDate !== getTodayIso();
  const xpProgress = profile.xp % 100;
  const mode = QUIZ_MODES.find((m) => m.id === selectedMode) ?? QUIZ_MODES[0];
  const best = profile.history
    .filter((h) => h.grade === selectedGrade && h.difficulty === selectedDifficulty)
    .reduce<null | (typeof profile.history)[number]>((b, c) => (!b || c.score > b.score ? c : b), null);

  return (
    <div className="pointer-events-none fixed inset-0 z-20 flex flex-col justify-between p-3 sm:p-5">
      {/* Top: player + resources + settings */}
      <div className="flex items-start justify-between gap-3">
        <div className="pointer-events-auto flex items-center gap-3">
          <div className="relative">
            <div className="flex h-16 w-16 items-center justify-center rounded-full border-4 border-white bg-gradient-to-b from-amber-300 to-orange-500 text-3xl shadow-lg">🦸</div>
            <div className="absolute -right-1 -bottom-1 flex h-7 min-w-7 items-center justify-center rounded-full border-2 border-white bg-blue-600 px-1 text-xs font-extrabold text-white">{profile.level}</div>
          </div>
          <div>
            <div className="text-lg font-extrabold text-white drop-shadow-[0_2px_0_rgba(0,0,0,.45)]">{profile.name}</div>
            <div className="mt-0.5 h-3.5 w-36 overflow-hidden rounded-full border-2 border-white/90 bg-slate-900/60">
              <div className="h-full rounded-full bg-gradient-to-r from-lime-300 to-emerald-500 transition-all" style={{ width: `${xpProgress}%` }} />
            </div>
            <div className="text-[11px] font-bold text-white/90 drop-shadow">Cấp {profile.level} · {xpProgress}/100 XP</div>
          </div>
        </div>

        <div className="pointer-events-auto flex flex-wrap items-center justify-end gap-2">
          <div className="res-pill">🪙 {formatNumber(profile.money)}</div>
          <div className="res-pill">💎 {formatNumber(profile.diamonds)}</div>
          <div className="res-pill">🔥 {profile.streak}</div>
          <button type="button" onClick={() => onOpenModal('settings')} aria-label="Cài đặt" className="btn-game !rounded-full !p-2.5" style={{ ['--c' as string]: '#64748b' }}>
            <Settings className="h-6 w-6" aria-hidden="true" />
          </button>
        </div>
      </div>

      {/* Logo */}
      <div className="pointer-events-none absolute inset-x-0 top-[4%] flex flex-col items-center px-4 text-center">
        <div className="logo-float">
          <div className="logo-sub">✨ Phiêu lưu cùng ✨</div>
          <div className="logo-main">TOÁN HỌC 3D</div>
          <div className="logo-tag">Math Master</div>
        </div>
      </div>

      {/* Bottom: side menu + PLAY + options */}
      <div className="flex items-end justify-between gap-3">
        <div className="pointer-events-auto flex gap-2">
          <RoundBtn label="Cửa hàng" color="#f59e0b" onClick={() => onOpenModal('shop')}><ShoppingBag className="h-7 w-7" aria-hidden="true" /></RoundBtn>
          <RoundBtn label="Lịch sử" color="#3b82f6" onClick={() => onOpenModal('history')}><ScrollText className="h-7 w-7" aria-hidden="true" /></RoundBtn>
          <RoundBtn label="Thống kê" color="#8b5cf6" onClick={() => onOpenModal('stats')}><BarChart3 className="h-7 w-7" aria-hidden="true" /></RoundBtn>
        </div>

        <div className="pointer-events-auto flex w-full max-w-md flex-col items-center gap-2">
          {showOptions && (
            <div className="game-panel pop-in w-full space-y-2.5 p-3.5">
              <div>
                <div className="chip-label">Lớp</div>
                <div className="flex flex-wrap gap-1.5">{GRADES.map((g) => <Chip key={g} active={selectedGrade === g} onClick={() => onChangeGrade(g)}>Lớp {g}</Chip>)}</div>
              </div>
              <div>
                <div className="chip-label">Độ khó</div>
                <div className="flex flex-wrap gap-1.5">{DIFFICULTIES.map((d) => <Chip key={d.id} active={selectedDifficulty === d.id} onClick={() => onChangeDifficulty(d.id)}>{d.id}</Chip>)}</div>
              </div>
              <div>
                <div className="chip-label">Chế độ</div>
                <div className="flex flex-wrap gap-1.5">{QUIZ_MODES.map((m) => <Chip key={m.id} active={selectedMode === m.id} onClick={() => onChangeMode(m.id)}>{m.label}</Chip>)}</div>
              </div>
            </div>
          )}

          <button type="button" onClick={() => setShowOptions((s) => !s)} className="game-panel pointer-events-auto inline-flex items-center gap-2 !rounded-full px-4 py-1.5 text-sm font-bold text-white">
            {showOptions ? <ChevronDown className="h-4 w-4" aria-hidden="true" /> : <ChevronUp className="h-4 w-4" aria-hidden="true" />}
            Tuỳ chọn chơi tự do · {mode.questionCount} câu
          </button>

          <button type="button" onClick={() => onOpenModal('map')} className="btn-game btn-play w-full" style={{ ['--c' as string]: '#22c55e' }}>
            <Play className="h-8 w-8" aria-hidden="true" fill="currentColor" />
            PHIÊU LƯU!
          </button>
          <button type="button" onClick={onRequestStart} className="btn-game !px-5 !py-1.5 !text-sm" style={{ ['--c' as string]: '#3b82f6' }}>
            Chơi tự do · Lớp {selectedGrade} · {selectedDifficulty}
          </button>
          <div className="text-xs font-bold text-white drop-shadow-[0_1px_0_rgba(0,0,0,.6)]">
            🏆 Kỷ lục: {best ? `${best.score.toFixed(1)}/10 · ${best.rank}` : 'chưa có'}
          </div>
        </div>

        <div className="pointer-events-auto flex">
          <RoundBtn label={unclaimedDaily ? 'Quà hôm nay' : 'Phần thưởng'} color="#ec4899" onClick={() => onOpenModal('daily')} badge={unclaimedDaily}>
            <Gift className="h-7 w-7" aria-hidden="true" />
          </RoundBtn>
        </div>
      </div>
    </div>
  );
}
