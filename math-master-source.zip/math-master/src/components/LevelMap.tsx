import { GRADES, STAGES, stageKey } from '../constants/gameConfig';
import type { Grade, PlayerProfile } from '../types/game';

interface LevelMapProps {
  profile: PlayerProfile;
  grade: Grade;
  onChangeGrade: (g: Grade) => void;
  onStart: (stage: number) => void;
}

export function LevelMap({ profile, grade, onChangeGrade, onStart }: LevelMapProps) {
  const starsOf = (n: number) => profile.stars?.[stageKey(grade, n)] ?? 0;
  const unlocked = (n: number) => n === 1 || starsOf(n - 1) >= 1;
  const total = STAGES.reduce((sum, st) => sum + starsOf(st.n), 0);

  const Node = ({ n }: { n: number }) => {
    const st = STAGES[n - 1];
    const open = unlocked(n);
    const stars = starsOf(n);
    const cleared = stars > 0;
    return (
      <button
        type="button"
        disabled={!open}
        onClick={() => onStart(n)}
        className="group relative z-10 flex w-20 flex-col items-center gap-1 sm:w-24"
        aria-label={`Màn ${n}: ${st.name}`}
      >
        <span
          className={`flex h-16 w-16 items-center justify-center rounded-full border-4 border-white text-3xl shadow-[0_5px_0_rgba(0,0,0,.3)] transition-transform sm:h-20 sm:w-20 sm:text-4xl ${
            !open
              ? 'bg-slate-400 grayscale'
              : cleared
                ? 'bg-gradient-to-b from-emerald-300 to-emerald-500 group-hover:scale-110'
                : 'btn-play-node bg-gradient-to-b from-amber-300 to-orange-500 group-hover:scale-110'
          }`}
        >
          {open ? st.emoji : '🔒'}
        </span>
        <span className="absolute -top-1 -left-1 flex h-6 w-6 items-center justify-center rounded-full border-2 border-white bg-blue-600 text-xs font-extrabold text-white">{n}</span>
        <span className="text-[11px] font-bold leading-tight text-slate-800 dark:text-slate-100">{st.name}</span>
        <span className="text-sm tracking-tight">
          {[1, 2, 3].map((i) => (
            <span key={i} className={i <= stars ? '' : 'opacity-25 grayscale'}>⭐</span>
          ))}
        </span>
      </button>
    );
  };

  const row = (nums: number[], reverse: boolean) => (
    <div className={`relative flex items-start justify-between ${reverse ? 'flex-row-reverse' : ''}`}>
      <div className="absolute inset-x-8 top-8 z-0 border-t-[6px] border-dashed border-amber-300 sm:top-10" />
      {nums.map((n) => (
        <Node key={n} n={n} />
      ))}
    </div>
  );

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex gap-1.5">
          {GRADES.map((g) => (
            <button key={g} type="button" onClick={() => onChangeGrade(g)} className={`chip !text-sm ${grade === g ? 'chip-on' : '!text-slate-700 !bg-slate-100 !border-slate-300 dark:!text-slate-200 dark:!bg-slate-800 dark:!border-slate-600'}`}>
              Lớp {g}
            </button>
          ))}
        </div>
        <div className="res-pill">⭐ {total}/{STAGES.length * 3}</div>
      </div>

      <div className="space-y-6 rounded-3xl bg-gradient-to-b from-sky-100 to-emerald-100 p-4 dark:from-slate-800 dark:to-slate-800/60">
        {row([1, 2, 3, 4], false)}
        <div className="-my-2 flex justify-end pr-8"><div className="h-8 border-l-[6px] border-dashed border-amber-300" /></div>
        {row([5, 6, 7, 8], true)}
      </div>

      <p className="text-center text-xs text-slate-500 dark:text-slate-400">
        Mỗi màn có 10 câu. Đúng từ 50% được 1⭐, từ 70% được 2⭐, từ 90% được 3⭐. Có ít nhất 1⭐ để mở màn tiếp theo!
      </p>
    </div>
  );
}
