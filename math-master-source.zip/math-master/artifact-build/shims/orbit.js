const T = window.THREE;
class Fallback extends T.EventDispatcher {
  constructor(cam, el) {
    super();
    this.object = cam; this.domElement = el; this.target = new T.Vector3();
    this.enablePan = false; this.enableZoom = true; this.enableRotate = true; this.enableDamping = false; this.dampingFactor = 0.05;
    this.minDistance = 1; this.maxDistance = 100; this.minPolarAngle = 0; this.maxPolarAngle = Math.PI; this.autoRotate = false;
    const off = new T.Vector3().copy(cam.position).sub(this.target);
    this.s = new T.Spherical().setFromVector3(off);
    let drag = false, lx = 0, ly = 0;
    el.addEventListener('pointerdown', e => { drag = true; lx = e.clientX; ly = e.clientY; this.dispatchEvent({ type: 'start' }); });
    window.addEventListener('pointerup', () => { if (drag) { drag = false; this.dispatchEvent({ type: 'end' }); } });
    window.addEventListener('pointermove', e => { if (!drag) return; this.s.theta -= (e.clientX - lx) * 0.006; this.s.phi -= (e.clientY - ly) * 0.006; lx = e.clientX; ly = e.clientY; });
    el.addEventListener('wheel', e => { e.preventDefault(); this.s.radius *= e.deltaY > 0 ? 1.08 : 0.92; }, { passive: false });
  }
  update() {
    const s = this.s;
    s.phi = Math.max(this.minPolarAngle, Math.min(this.maxPolarAngle, s.phi));
    s.radius = Math.max(this.minDistance, Math.min(this.maxDistance, s.radius));
    this.object.position.setFromSpherical(s).add(this.target);
    this.object.lookAt(this.target);
    return true;
  }
  dispose() {}
}
export const OrbitControls = window.THREE.OrbitControls || Fallback;
