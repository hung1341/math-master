const T = window.THREE;
export class RoomEnvironment extends T.Scene {
  constructor() {
    super();
    const room = new T.Mesh(new T.BoxGeometry(6, 6, 6), new T.MeshBasicMaterial({ color: 0x777777, side: T.BackSide }));
    room.position.y = 3; this.add(room);
    const lights = [[0,5.8,0,3,0.2,3,6],[-5.8,3,0,0.2,3,3,2.5],[5.8,3,0,0.2,3,3,2.5],[0,3,-5.8,3,3,0.2,3],[0,3,5.8,3,3,0.2,1.5]];
    lights.forEach(([x,y,z,w,h,d,i]) => {
      const m = new T.Mesh(new T.BoxGeometry(w,h,d), new T.MeshBasicMaterial({ color: new T.Color(i,i,i) }));
      m.position.set(x,y,z); this.add(m);
    });
  }
  dispose() {}
}
