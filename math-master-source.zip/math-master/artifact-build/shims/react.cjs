module.exports = window.React;
