import React from 'react';
const mk = (name, children) => {
  const C = ({ size = 24, strokeWidth = 2, className = '', color = 'currentColor', ...rest }) =>
    React.createElement('svg', { xmlns: 'http://www.w3.org/2000/svg', width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: color, strokeWidth, strokeLinecap: 'round', strokeLinejoin: 'round', className, ...rest },
      children.map((c, i) => React.createElement(c[0], { key: i, ...c[1] })));
  C.displayName = name; return C;
};
const p = d => ['path', { d }];
const circ = (cx, cy, r) => ['circle', { cx, cy, r }];
export const Award = mk('Award', [circ(12,8,6), p('M15.477 12.89 17 22l-5-3-5 3 1.523-9.11')]);
export const Check = mk('Check', [p('M20 6 9 17l-5-5')]);
export const CheckCircle2 = mk('CheckCircle2', [circ(12,12,10), p('m9 12 2 2 4-4')]);
export const Clock = mk('Clock', [circ(12,12,10), p('M12 6v6l4 2')]);
export const Delete = mk('Delete', [p('M10 5a2 2 0 0 0-1.344.519l-6.328 5.74a1 1 0 0 0 0 1.481l6.328 5.741A2 2 0 0 0 10 19h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2z'), p('m12 9 6 6'), p('m18 9-6 6')]);
export const Gift = mk('Gift', [['rect',{x:3,y:8,width:18,height:4,rx:1}], p('M12 8v13'), p('M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7'), p('M7.5 8a2.5 2.5 0 0 1 0-5A4.8 8 0 0 1 12 8a4.8 8 0 0 1 4.5-5 2.5 2.5 0 0 1 0 5')]);
export const Home = mk('Home', [p('M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8'), p('M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z')]);
export const Lightbulb = mk('Lightbulb', [p('M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5'), p('M9 18h6'), p('M10 22h4')]);
export const LogOut = mk('LogOut', [p('M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4'), p('m16 17 5-5-5-5'), p('M21 12H9')]);
export const RotateCcw = mk('RotateCcw', [p('M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8'), p('M3 3v5h5')]);
export const Send = mk('Send', [p('M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z'), p('m21.854 2.147-10.94 10.939')]);
export const Settings = mk('Settings', [p('M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z'), circ(12,12,3)]);
export const ShieldCheck = mk('ShieldCheck', [p('M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z'), p('m9 12 2 2 4-4')]);
export const X = mk('X', [p('M18 6 6 18'), p('m6 6 12 12')]);
export const XCircle = mk('XCircle', [circ(12,12,10), p('m15 9-6 6'), p('m9 9 6 6')]);
export const BarChart3 = mk('BarChart3', [p('M3 3v16a2 2 0 0 0 2 2h16'), p('M18 17V9'), p('M13 17V5'), p('M8 17v-3')]);
export const ChevronDown = mk('ChevronDown', [p('m6 9 6 6 6-6')]);
export const ChevronUp = mk('ChevronUp', [p('m18 15-6-6-6 6')]);
export const Play = mk('Play', [p('M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z')]);
export const ScrollText = mk('ScrollText', [p('M15 12h-5'), p('M15 8h-5'), p('M19 17V5a2 2 0 0 0-2-2H4'), p('M8 21h12a2 2 0 0 0 2-2v-1a1 1 0 0 0-1-1H11a1 1 0 0 0-1 1v1a2 2 0 1 1-4 0V5a2 2 0 1 0-4 0v2a1 1 0 0 0 1 1h3')]);
export const ShoppingBag = mk('ShoppingBag', [p('M16 10a4 4 0 0 1-8 0'), p('M3.103 6.034h17.794'), p('M3.4 5.467a2 2 0 0 0-.4 1.2V20a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6.667a2 2 0 0 0-.4-1.2l-2-2.667A2 2 0 0 0 17 2H7a2 2 0 0 0-1.6.8z')]);
export const Camera = mk('Camera', [p('M13.997 4a2 2 0 0 1 1.76 1.05l.486.9A2 2 0 0 0 18.003 7H20a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h1.997a2 2 0 0 0 1.759-1.048l.489-.904A2 2 0 0 1 10.004 4z'), circ(12,13,3)]);
export const Monitor = mk('Monitor', [['rect',{width:20,height:14,x:2,y:3,rx:2}], p('M8 21h8'), p('M12 17v4')]);
export const Plus = mk('Plus', [p('M5 12h14'), p('M12 5v14')]);
export const Snowflake = mk('Snowflake', [p('m10 20-1.25-2.5L6 18'), p('M10 4 8.75 6.5 6 6'), p('m14 20 1.25-2.5L18 18'), p('m14 4 1.25 2.5L18 6'), p('m17 21-3-6h-4'), p('m17 3-3 6 1.5 3'), p('M2 12h6.5L10 9'), p('m20 10-1.5 2 1.5 2'), p('M22 12h-6.5L14 15'), p('m4 10 1.5 2L4 14'), p('m7 21 3-6-1.5-3'), p('m7 3 3 6h4')]);
export const Trash2 = mk('Trash2', [p('M10 11v6'), p('M14 11v6'), p('M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6'), p('M3 6h18'), p('M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2')]);
export const User = mk('User', [p('M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2'), circ(12,7,4)]);
export const Volume2 = mk('Volume2', [p('M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z'), p('M16 9a5 5 0 0 1 0 6'), p('M19.364 18.364a9 9 0 0 0 0-12.728')]);
export const VolumeX = mk('VolumeX', [p('M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z'), p('m22 9-6 6'), p('m16 9 6 6')]);
