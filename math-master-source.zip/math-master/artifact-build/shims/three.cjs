const T = window.THREE;
T.SRGBColorSpace = 'srgb';
// r147 compat: map new colorSpace props to old encoding props
Object.defineProperty(T.WebGLRenderer.prototype, 'outputColorSpace', { set(v){ this.outputEncoding = T.sRGBEncoding; }, get(){ return 'srgb'; }, configurable: true });
Object.defineProperty(T.Texture.prototype, 'colorSpace', { set(v){ this.encoding = T.sRGBEncoding; }, get(){ return 'srgb'; }, configurable: true });
module.exports = T;
// r147 compat: InstancedMesh.computeBoundingSphere/Box were added later
if (!T.InstancedMesh.prototype.computeBoundingSphere) {
  T.InstancedMesh.prototype.computeBoundingSphere = function () { this.frustumCulled = false; };
  T.InstancedMesh.prototype.computeBoundingBox = function () { this.frustumCulled = false; };
}
