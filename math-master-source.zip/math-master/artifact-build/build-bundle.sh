#!/bin/sh
# Bản build một-file cho artifact/trình duyệt (React, Three.js nạp từ CDN). Chạy từ thư mục gốc dự án:
#   sh artifact-build/build-bundle.sh   (cần esbuild)
npx esbuild src/main.tsx --bundle --minify --format=iife --jsx=transform \
  --tsconfig-raw='{"compilerOptions":{"jsx":"react"}}' --inject:artifact-build/shims/inject.js --target=es2020 \
  --alias:react=./artifact-build/shims/react.cjs --alias:react-dom/client=./artifact-build/shims/react-dom-client.cjs \
  --alias:lucide-react=./artifact-build/shims/lucide.js \
  --alias:three/addons/controls/OrbitControls.js=./artifact-build/shims/orbit.js \
  --alias:three/addons/environments/RoomEnvironment.js=./artifact-build/shims/room.js \
  --alias:three=./artifact-build/shims/three.cjs --loader:.css=empty --outfile=artifact-build/bundle.js
